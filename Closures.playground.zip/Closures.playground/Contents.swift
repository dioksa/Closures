// https://medium.com/@abhimuralidharan/functional-swift-all-about-closures-310bc8af31dd
// https://www.programiz.com/swift-programming/closures
// https://medium.com/ios-os-x-development/https-medium-com-pavelgnatyuk-autoclosure-what-why-and-when-swift-641dba585ece
// https://www.programiz.com/swift-programming/closures
// https://learnappmaking.com/closures-swift-how-to/
// https://www.journaldev.com/15163/swift-closure

/// Delegates vs Closure Callbacks
// https://itnext.io/delegates-vs-closure-callbacks-f36f9029217d
// https://medium.cobeisfresh.com/why-you-shouldn-t-use-delegates-in-swift-7ef808a7f16b
// https://stablekernel.com/use-blocks-closures-delegates-callbacks/

/// Closures are self-contained blocks of functionality that can be passed around and used in code

/// Closures are mainly used for two reasons:

/// 1. Completion blocks
/// Closures help you to be notified when some task has finished its execution.
/// 2. Higher order functions
/// Closures can be passed as an input parameters for higher order functions. A higher order function is just a type of function that accepts function as an input and returns value of type function as output.
/// For this purpose it's better to use closures in replacement of function because closure omits the func keyword and function name that makes the code more readable and short.

// Forms of Closure in Swift
/// Global functions
/// Nested functions
/// Closures expression

// Closure syntax

/// { (parameters) -> return type in
///    statements
/// }

// Function syntax

/// func name(parameters) -> (return type) {
///    body of function
/// }

import Foundation

// Hello world -> func VS closure
func helloWorldFunc() {
    print("Hello world in function")
}

let helloWorldClosure = {
    print("Hello world in closure")
}

helloWorldFunc()
helloWorldClosure()

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/// simple closure takes no parameters, contains no statements and does not return a value.
/// This closure is assigned to the constant simpleClosure.

let simpleClosure = { }
simpleClosure()

// Example 1
func calculateNumbers(a: Int, b: Int) -> Int {
    return a + b
}

let sum = calculateNumbers(a: 3, b: 5)

var sumOfNumbers: (Int, Int) -> Int = { $0 + $1 }
let closureSum = sumOfNumbers(4, 9)

var calculate: (Int, Int) -> Int = { (number1, number2) in      /// closure takes two parameters (Int, Int)
    return number1 + number2                                    /// returns one value (Int)
}                                                               /// (number1, number2) -> parameters that closure takes

calculate(12, 5)

// Example 2, closure with no parameters, but with return value
let string: () -> String = { return "Some value" }
print(string())

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

func printMyName(closure: () -> String) -> String {
    return closure()
}

printMyName { () -> String in
    return "Oksana"
}

// Example 3, function has no parameters, but closure has two parameters of Int type
func calculateNumbersInClosure() -> (Int, Int) -> Int { /// take two numbers and return one
    return sumOfNumbers /// takes two parameters and after some actions returns sum of this two parameters
}

calculateNumbersInClosure()(5, 10)

var someNewClosure = calculateNumbersInClosure()
someNewClosure(1, 6)

// Example 4
/// function takes two parameters: closure and array of numbers
func filterNumbers(closure: (Int) -> Bool, numbers: [Int]) -> [Int] {
    var allNumbers = [Int]()
    
    for number in numbers {
        if closure(number) {
            allNumbers.append(number)
        }
    }
    
    return allNumbers
}

let arrayOfNumbers = [1, 5, 46, 6, 36, 83, 3]

func greaterThan(_ value: Int) -> Bool {
    return value > 30
}

let filteredList = filterNumbers(closure: { (number) -> Bool in
    return number < 10
}, numbers: arrayOfNumbers)

let anotherFilteredList = filterNumbers(closure: greaterThan, numbers: arrayOfNumbers)

// Example 4.1
func appendString(_ firstString: String, _ secondString: String) -> String {
    return firstString + ": " + secondString
}

var appendStringInClosure = { (firstString: String, secondString: String) -> String in
    return firstString + ": " + secondString
}

var appendStringInClosureShortStyle = {
    return $0 + ": " + $1
}

print(appendString("Welcome", "here"))
print(appendStringInClosure("Welcome", "here again")) // -> result is the same
print(appendStringInClosureShortStyle("Welcome", "here"))

// Example 4.2, function takes closure with one parameter, that returns Void
func travel(action: (String) -> Void) {
    print("Function start action")
    action("")
    print("End of function")
}

travel(action: { action in
    print("Action name \(action)")
})

// Example 5, function that assigned to a variable
func countLetters(word: String) -> Int {
    return word.count
}

let resultOfFunction = countLetters(word: "Result") /// -> returns only result of function
let newsClosureVariable: (String) -> Int = countLetters /// means it store a pointer to a function that accepts a String and returns an Int

/// Result of closure and function will be the same
let result = newsClosureVariable("Nellie")
countLetters(word: "Nellie")

// Example 6, no labels required for variables, but needed for functions
let wordCount = { (word: String) -> Int in
    return word.count
}

//wordCount(word: "No name parameters needed") -> ERROR: Extraneous argument label 'word:' in call
wordCount("No name parameters needed")

func wordCount(count: () -> Int) {}
wordCount(count: { () -> Int in
    return 53
})

// Example 7, trailing closure -> When the closure is being passed as the final argument to a function we can pass it as a trailing closure

func printMessage(text: String, closure: () -> ()) {
    print(text)
    closure()
}

printMessage(text: "Some text") {
    print("This type of closure written outside of function call parentheses is known as trailing closure")
}

// Example 8, @autoclosure removes curly brackets around closure body
func closureWithoutCurlyBrackets(someClosure: @autoclosure () -> Bool, message: String) {
    print(message)
    someClosure()
}

closureWithoutCurlyBrackets(someClosure: 1 > 2, message: "message")               /// @autoclosure
// closureWithoutCurlyBrackets(someClosure: { 1 > 2 }, message: "message")            common closure

// Example 9, Escaping vs No Escaping Closures

/// A closure is said to be no escaping when the closure is passed as an argument to the function, and is called before the function returns. The closure is not used outside of the function.

/// In Swift, all closure parameters are no escaping by default.

/// A closure is said to escape a function when the closure is passed as an argument to the function, but is called after the function returns or the closure is used outside of the body of the function.

var closureArray: [() -> ()] = []

func testFunctionWithEscapingClosure(myClosure: @escaping () -> Void) {
    print("function called")
    closureArray.append(myClosure)
    myClosure()
    return
}

testFunctionWithEscapingClosure {
     print("closure called")
}

// Example 10, completion handler
/// Completion handler are callbacks/notifications that allows to perform some action when a function completes its task.

func handleRequest(completion: () -> ()) {
    print("before calling callback")
    completion()
    print("after calling callback")
}

handleRequest() {
    print("call back received")
}

// Example 10.1

var closeButtonPressed = true

func playMusic(completion: (String) -> ()) {
    print("Music is on")
    
    if closeButtonPressed {
        completion("Turn music off")
    }
}

playMusic { (action) in
    print(action)
}

// Example 11 -> Closures inside Functions
/// Function accepts two numbers and closure -> function that do some actions with numbers
func doSomeActions(number1: Int, number2: Int, closure: (Int, Int) -> Int) -> Int {
    return closure(number1, number2)
}

let plus: (Int, Int) -> Int = { $0 + $1 }
let minus: (Int, Int) -> Int = { $0 - $1 }

print(doSomeActions(number1: 2, number2: 3, closure: plus))
print(doSomeActions(number1: 7, number2: 4, closure: minus))

// Closures vs Delegates

/// 1. Delegate has to implement every method in the protocol.
/// 1. Closures cares about when methods will be calling, they don't have delegate and not all of the methods need to be implemented.

/// 2. Multiple delegation - a lot of different delegates for different actions
/// 2. With callbacks,it's possible to define an array of functions and call each of those when something’s done.

/// 3. To test delegate is more difficult than closure.
/// In one test, you might test if the callback gets called, then in another you might test if it’s called with the right results. And none of those require a complicated mocked delegate.

// Resume:
/// 1. The main reason behind the idea of closures is convenience. It provides a convenient way to work with functions. It's kind of like following the "Write less, do more" principle.
/// 2. One more things is that it's not required to use labels when you invoke a closure with parameters.
/// 3. It's better to use closures than delegates.
